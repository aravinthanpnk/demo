#!/usr/bin/env ruby
#encoding: utf-8

puts "Hello Aravinthan!"